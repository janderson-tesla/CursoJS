// Favorite Song Details

//Variables
var nameSong = "Lose yourself";
var Artist = "Eminem";
var Genre = "Hip Hop";
var Length = "5:20"
var DurationInSeconds = 312;
var SongWriter = "Marshall Matters";
var Studio = "54 Sound Studio"
var Released = "October 28,2002";
var Recorded = "September 2001 -2002";

console.log("NameSong: " + nameSong);
console.log("Artist: " + Artist);
console.log("Genre: " + Genre);
console.log("Length: " + Length);
console.log("Duration in Seconds: " + DurationInSeconds);
console.log("SongWriter: " + SongWriter);
console.log("Studio: " + Studio);
console.log("Released: " + Released);
console.log("Recorded: " + Recorded);


// Object mode

var SongData = {
    nameSong: "Lose yourself",
    Artist: "Eminem",
    Genre: "Hip Hop",
    Length: "5:20",
    DurationInSeconds: 312,
    SongWriter: "Marshall Matters",
    Studio: "54 Sound Studio",
    Released: "October 28,2002",
    Recorded: "September 2001 -2002",
};

console.log(SongData);